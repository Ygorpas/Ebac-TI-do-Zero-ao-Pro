// Seleciona o formulário e o parágrafo de status
const form = document.getElementById('form-contato');
const mensagemStatus = document.getElementById('mensagem-status');

// Evento de envio do formulário
form.addEventListener('submit', function (event) {
  event.preventDefault(); // Evita recarregar a página

  // Dados do formulário
  const dadosFormulario = {
    nome: form.nome.value,
    email: form.email.value,
    mensagem: form.mensagem.value
  };

  // Envia os dados com Fetch API
  fetch('https://exemplo.com/api/contato', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(dadosFormulario)
  })
    .then(response => {
      if (response.ok) {
        mensagemStatus.textContent = 'Mensagem enviada com sucesso!';
        mensagemStatus.style.color = 'green';
        form.reset();
      } else {
        throw new Error('Erro no envio');
      }
    })
    .catch(error => {
      mensagemStatus.textContent = 'Erro ao enviar mensagem. Tente novamente.';
      mensagemStatus.style.color = 'red';
      console.error('Erro:', error);
    });
});

// Importando o módulo Express
const express = require('express');

// Criando uma instância do Express
const app = express();

// Definindo a porta da aplicação
const PORT = 3000;

// Array de serviços disponíveis no pet shop
const servicos = [
  { id: 1, nome: "Banho e Tosa", descricao: "Banho completo para cães e gatos." },
  { id: 2, nome: "Consulta Veterinária", descricao: "Atendimento clínico para pets." }
];

// Rota raiz - Mensagem de boas-vindas
app.get('/', (req, res) => {
  res.send('🐾 Bem-vindo ao Pet Shop AuMiaus! 🐶🐱');
});

// Rota para listar todos os serviços
app.get('/servicos', (req, res) => {
  res.json(servicos);
});

// Inicializando o servidor
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT} 🚀`);
});
